মিয়াজী ইন্টারনেট Admin Billing Panel

ফাইল: miazi-internet-billing-login.html

Supabase Project URL এবং Publishable Key ফাইলে বসানো হয়েছে।
ব্যবহার:
1. GitHub repository-তে HTML ফাইলটি index.html নামে আপলোড করুন।
2. Supabase Dashboard > Authentication > URL Configuration-এ আপনার GitHub Pages URL-টি Site URL হিসেবে দিন।
3. Redirect URLs-এ একই GitHub Pages URL যোগ করুন।
4. GitHub Pages চালু করে ওয়েবসাইট খুলুন।
5. Authentication-এ তৈরি করা ইমেইল ও পাসওয়ার্ড দিয়ে লগইন করুন।

গুরুত্বপূর্ণ:
- Publishable key ব্রাউজারে ব্যবহারের জন্যই তৈরি; Secret/service_role key কখনো HTML-এ দেবেন না।
- বর্তমান গ্রাহক/বিল/পেমেন্ট ডেটা Local Storage-এ থাকে, Supabase Database-এ নয়।
- HTML ফাইলটি HTTPS-এ চালান।
